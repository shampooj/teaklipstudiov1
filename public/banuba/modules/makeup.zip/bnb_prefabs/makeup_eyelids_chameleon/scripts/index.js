const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const settings = JSON.parse(require("./settings.js"))

const default_threshold = 0.92;
const default_contour = 0.3;
const default_weakness = 0.25;

const max_colors_amount = 3;

class MakeupEyelidsChameleon extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        
        /* bottom colors */
        this.regions0 = [
            new FaceRegion("eyelids_chameleon_00", settings),
            new FaceRegion("eyelids_chameleon_01", settings),
            new FaceRegion("eyelids_chameleon_02", settings),
        ]
        
        /* top colors */
        this.regions1 = [
            new FaceRegion("eyelids_chameleon_10", settings),
            new FaceRegion("eyelids_chameleon_11", settings),
            new FaceRegion("eyelids_chameleon_12", settings),
        ]
        
        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness);
        
        MakeupBase.addModeCallback(this.onModeChanged);
    }

    setPrefabSettings(state) {
        this.clear();

        if (!state.hasOwnProperty("colors")) {
            return;
        }

        if ((state.colors.hasOwnProperty("bottom") && state.colors['bottom'].length > max_colors_amount)
            || (state.colors.hasOwnProperty("upper") && state.colors['upper'].length > max_colors_amount)) {
            bnb.log(`[WARN] Colors amount exceeded!`);
        }

        if (state.colors.hasOwnProperty("bottom")) {
            for (const [i, s] of state.colors['bottom'].entries()) {
                if (i > this.regions0.length) break
                MakeupBase.apply(this.regions0[i], s)
            }
        }

        if (state.colors.hasOwnProperty("upper")) {
            for (const [i, s] of state.colors['upper'].entries()) {
                if (i > this.regions1.length) break
                MakeupBase.apply(this.regions1[i], s)
            }
        }

        /* set chameleon mask params */
        this.threshold(state.threshold);
        this.contour(state.contour);
        this.weakness(state.weakness);
    }
    
    onModeChanged = (isQuality) => {
        if (isQuality) {
            // quality mode requires skin_nn and face_nn
            const nns0 = ["skin_nn", "face_nn"];
            this.regions0[0]._set_nns(nns0);
            this.regions0[1]._set_nns(nns0);
            this.regions0[2]._set_nns(nns0);
            
            const nns1 = ["skin_nn", "face_nn", "eyelids_chameleon_nn"];
            this.regions1[0]._set_nns(nns1);
            this.regions1[1]._set_nns(nns1);
            this.regions1[2]._set_nns(nns1);
        } else {
            // speed mode requires lips and brows to cut them from face_nn.
            const nns0 = ["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn"];
            this.regions0[0]._set_nns(nns0);
            this.regions0[1]._set_nns(nns0);
            this.regions0[2]._set_nns(nns0);
            
            const nns1 = ["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn", "eyelids_chameleon_nn"];
            this.regions1[0]._set_nns(nns1);
            this.regions1[1]._set_nns(nns1);
            this.regions1[2]._set_nns(nns1);
        }
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }

    clear() {
        for (const region of this.regions0) region.clear()
        for (const region of this.regions1) region.clear()

        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_CHAMELEON, [this.params]);
    }
}

exports = {
    MakeupEyelidsChameleon
}
