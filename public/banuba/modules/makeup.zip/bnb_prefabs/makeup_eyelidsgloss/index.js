const prefabs = require("bnb_js/prefabs");
const { MakeupBase, FaceRegion, FaceRegionBase } = require("bnb_prefabs/makeup_base/scripts/index.js")

const default_threshold = 0.98;
const default_contour = 0.5;
const default_weakness = 0.5;
const default_multiplier = 1.5;
const default_saturation = 0.1;
const default_alpha = 0.0;

class MakeupEyelidsgloss extends prefabs.Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        
        this.region = new FaceRegionBase("eyelids_gloss");

        this.params = new bnb.FeatureParameter(default_threshold, default_contour, default_weakness, 0.0);

        /* send those params to cpu (Don't send them from JS directly to gpu).
         Later cpu will send them to gpu. It helps to sync changes of params and masks on gpu. */
        this.gpu_params = new bnb.FeatureParameter(default_multiplier, default_alpha, 0.0, 0.0);
        
        MakeupBase.addModeCallback(this.onModeChanged);
    }
    
    onModeChanged = (isQuality) => {
        if (isQuality) {
            /* quality mode requires skin_nn and face_nn */
            this.region._set_nns(["skin_nn", "face_nn", "eyelids_gloss_nn"]);
        } else {
            /* speed mode requires lips and brows to cut them from face_nn */
            this.region._set_nns(["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn", "eyelids_gloss_nn"]);
        }
    }
    
    threshold(value) {
        this.params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }
    
    contour(value) {
        this.params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }
    
    weakness(value) {
        this.params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }

    multiplier(value) {
        this.gpu_params.x = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }

    saturation(value) {
        this.gpu_params.y = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }

    alpha(value) {
        this.gpu_params.z = value;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);

        if (value == 0.)
          this.region._hide();
        else
          this.region._show();
    }
    
    clear() {
        this.params.x = default_threshold;
        this.params.y = default_contour;
        this.params.z = default_weakness;
        this.gpu_params.x = default_multiplier;
        this.gpu_params.y = default_saturation;
        this.gpu_params.z = default_alpha;
        bnb.scene.addFeatureParam(bnb.FeatureID.EYELIDS_GLOSS, [this.params, this.gpu_params]);
    }
}

exports = {
    MakeupEyelidsgloss
}
