#include <bnb/glsl.frag>

BNB_IN(0)
vec2 var_uv;
BNB_IN(1)
vec2 var_skin_uv;
BNB_IN(2)
vec2 var_face_uv;
BNB_IN(3)
float var_fake_skin;

BNB_DECLARE_SAMPLER_2D(0, 1, tex);
BNB_DECLARE_SAMPLER_2D(2, 3, skin);
BNB_DECLARE_SAMPLER_2D(4, 5, face);

void main()
{
    float m = fake_skin_nn_active.x < 0.5 ? BNB_TEXTURE_2D_LOD(BNB_SAMPLER_2D(skin), var_skin_uv, 0.).x : var_fake_skin;
    m *= sqrt(BNB_TEXTURE_2D_LOD(BNB_SAMPLER_2D(face), var_face_uv, 0.).x); // sqrt to make face mask to not darken edges too much
    bnb_FragColor = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex), var_uv) * m;
}
