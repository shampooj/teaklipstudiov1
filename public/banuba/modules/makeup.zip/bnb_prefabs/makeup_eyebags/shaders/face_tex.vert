#include <bnb/glsl.vert>

BNB_LAYOUT_LOCATION(0)
BNB_IN vec3 attrib_pos;
BNB_LAYOUT_LOCATION(2)
BNB_IN vec2 attrib_uv;
BNB_LAYOUT_LOCATION(3)
BNB_IN vec4 attrib_red_mask;

BNB_OUT(0)
vec2 var_uv;
BNB_OUT(1)
vec2 var_skin_uv;
BNB_OUT(2)
vec2 var_face_uv;
BNB_OUT(3)
float var_fake_skin;

BNB_DECLARE_SAMPLER_2D(6, 7, correction_morph);

void main()
{
    vec3 vpos = attrib_pos;
    vpos += texelFetch(BNB_SAMPLER_2D(correction_morph), ivec2(gl_VertexID % (3308 / 2), gl_VertexID / (3308 / 2)), 0).xyz;
    gl_Position = bnb_MVP * vec4(vpos, 1.);
    vec2 v = gl_Position.xy / gl_Position.w;

    var_uv = attrib_uv;
    var_skin_uv = vec2(vec4(v, 1., 1.) * skin_nn_transform);
    var_face_uv = vec2(vec4(v, 1., 1.) * face_nn_transform);

    var_fake_skin = 1. - (attrib_red_mask.y + attrib_red_mask.z);
}
