const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion, FaceRegionBase } = require("bnb_prefabs/makeup_base/scripts/index.js")

class MakeupEyebags extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        this.region = new FaceRegionBase("eyebags");
        MakeupBase.addModeCallback(this.onModeChanged);

        this.parameter = bnb.scene.getAssetManager().findMaterial("shaders/eyebags/tone").findParameter("eyebags_alpha")
    }

    onModeChanged = (isQuality) => {
        if (isQuality) {
            // quality mode requires skin_nn and face_nn
            this.region._set_nns(["skin_nn", "face_nn"]);
        } else {
            // speed mode requires only face_nn.
            this.region._set_nns(["face_nn"]);
        }
    }

    alpha(a) {
        const { x, y, z, w } = this.parameter.getVector4();
        this.parameter.setVector4(new bnb.Vec4(a, y, z, w));
        
        if (a > 0.0)
            this.region._show();
        else
            this.region._hide();
    }

    clear() {
        this.alpha(0.8)
    }
}

exports = {
    MakeupEyebags
}
