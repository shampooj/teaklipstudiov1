const prefabs = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion, FaceRegionBase } = require("bnb_prefabs/makeup_base/scripts/index.js")

const default_lips_glitter_light_dir = new bnb.Vec4(0.5, 0.3, 0.8, 0);

class MakeupLipsGlitter extends prefabs.Base {
    constructor(faceIndex = 0) {
        super(faceIndex);

        this.region = new FaceRegionBase("lips_glitter", ["lips_nn"])

        this.cached_glitter_color_alpha = new bnb.Vec4(0, 0, 0, 0);

        const glitter_mat = bnb.scene.getAssetManager().findMaterial("lips_glitter_mat");
        this.glitter_color_alpha_param = glitter_mat.findParameter("lips_glitter_color_alpha");
        this.glitter_light_dir_param = glitter_mat.findParameter("lips_glitter_light_dir");
    }

    color(value) {
        const _value = prefabs.parseColor(value);
        this.cached_glitter_color_alpha.x = _value.x;
        this.cached_glitter_color_alpha.y = _value.y;
        this.cached_glitter_color_alpha.z = _value.z;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);
    }

    alpha(value) {
        const _value = Math.min(Math.max(value, 0.0), 1.0);
        this.cached_glitter_color_alpha.w = _value;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);

        if (_value > 0.0)
          this.region._show();
        else
          this.region._hide();
    }
    
    lightDirection(vector) {
        const values = vector.split(" ").map(parseFloat);

        let square_sum = values[0] * values[0] + values[1] * values[1] + values[2] * values[2];
        if (square_sum > 0.01)
            this.glitter_light_dir_param.setVector4(new bnb.Vec4(values[0], values[1], values[2], 0));
        else
            this.glitter_light_dir_param.setVector4(default_lips_glitter_light_dir);
    }

    clear() {
        this.glitter_color_alpha_param.setVector4(prefabs.parseColor("0 0 0 0"));
        this.glitter_light_dir_param.setVector4(default_lips_glitter_light_dir);
        this.region._hide();
    }
}

exports = {
    MakeupLipsGlitter
}
