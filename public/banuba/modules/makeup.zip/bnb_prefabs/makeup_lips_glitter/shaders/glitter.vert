#include <bnb/glsl.vert>

layout(location = 0) in vec3 attrib_pos;

BNB_OUT(0)
vec2 var_bg_uv;
BNB_OUT(1)
vec2 var_lips_uv;
BNB_OUT(2)
vec3 var_v;
flat BNB_OUT(3)
    vec3 light_dir;

void main()
{
    vec3 vpos = attrib_pos;
    gl_Position = bnb_MVP * vec4(vpos, 1.);

    vec2 v = gl_Position.xy / gl_Position.w;

    var_bg_uv = v * 0.5 + 0.5;
#if defined(BNB_VK_1)
    var_bg_uv.y = 1. - var_bg_uv.y;
#endif
    var_lips_uv = (vec4(v, 1., 1.) * lips_nn_transform).xy;
    var_v = (bnb_MV * vec4(attrib_pos, 1.)).xyz;

    light_dir = normalize(lips_glitter_light_dir.xyz);
}
