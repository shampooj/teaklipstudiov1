/* For additional information please read banuba_sdk/misc/one_stage_makeup/README.md */

#include <bnb/glsl.vert>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"
#include "bnb_prefabs/makeup_base/shaders/weights.glsl"
#include "bnb_prefabs/makeup_base/shaders/makeup_params.glsl"
#include <bnb/matrix_operations.glsl>
#include <bnb/color_spaces.glsl>

#define FLT_MIN 0.00588f // (1.5f / 255.f)

BNB_LAYOUT_LOCATION(0)
BNB_IN vec3 attrib_pos;

BNB_OUT(0)
vec2 var_uv;
BNB_OUT(1)
vec4 lips_gloss_chameleon_uv;
BNB_OUT(2)
vec4 eyelids_gloss_chameleon_uv;

flat BNB_OUT(3) vec2 mean_foundation;
flat BNB_OUT(4) vec2 mean_concealer;
flat BNB_OUT(5) vec2 mean_contour;
flat BNB_OUT(6) vec2 mean_highlighter;
flat BNB_OUT(7) vec2 mean_blush;
flat BNB_OUT(8) vec2 mean_lipstick;
flat BNB_OUT(9) vec2 mean_lips_chameleon_0;
flat BNB_OUT(10) vec2 mean_lips_chameleon_1;
flat BNB_OUT(11) vec2 mean_lipsliner;
flat BNB_OUT(12) vec2 mean_eyeshadow_0;
flat BNB_OUT(13) vec2 mean_eyeshadow_1;
flat BNB_OUT(14) vec2 mean_eyeshadow_2;
flat BNB_OUT(15) vec2 mean_eyelids_chameleon_00;
flat BNB_OUT(16) vec2 mean_eyelids_chameleon_01;
flat BNB_OUT(17) vec2 mean_eyelids_chameleon_02;
flat BNB_OUT(18) vec2 mean_eyelids_chameleon_10;
flat BNB_OUT(19) vec2 mean_eyelids_chameleon_11;
flat BNB_OUT(20) vec2 mean_eyelids_chameleon_12;
flat BNB_OUT(21) vec2 mean_eyeliner;
flat BNB_OUT(22) vec2 mean_eyebrows;

#ifdef BNB_MEANS_DEBUG
flat BNB_OUT(23) vec3 debug_mean_skin_rgb;
flat BNB_OUT(24) vec3 debug_mean_brows_rgb;
flat BNB_OUT(25) vec3 debug_mean_lips_rgb;
flat BNB_OUT(26) vec3 debug_mean_lipsliner_rgb;
flat BNB_OUT(27) vec3 debug_mean_concealer_rgb;
flat BNB_OUT(28) vec3 debug_mean_contour_rgb;
flat BNB_OUT(29) vec3 debug_mean_highlighter_rgb;
flat BNB_OUT(30) vec3 debug_mean_blush_rgb;
flat BNB_OUT(31) vec3 debug_mean_shadow_0_rgb;
flat BNB_OUT(32) vec3 debug_mean_shadow_1_rgb;
flat BNB_OUT(33) vec3 debug_mean_shadow_2_rgb;
flat BNB_OUT(34) vec3 debug_mean_eyeliner_rgb;
#endif

BNB_DECLARE_SAMPLER_2D(0, 1, tex_makeup_colors);
BNB_DECLARE_SAMPLER_2D(2, 3, tex_means);
BNB_DECLARE_SAMPLER_2D(4, 5, tex_weights);

/* calculated means and weights for all layers */
vec2 result_means_vs[BNB_MAKEUP_MASKED_LAYERS];
vec3 result_means_rgb[BNB_MAKEUP_MASKED_LAYERS];
float result_weights_sum[BNB_MAKEUP_MASKED_LAYERS] = float[BNB_MAKEUP_MASKED_LAYERS](
    0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f
);

vec3 update_mean(vec3 source_mean_rgb, vec5 new_vsc, vec2 mean_vs, vec3 ac_alpha)
{
    float alpha = ac_alpha[2];

    if (alpha < FLT_MIN)
        return source_mean_rgb;

    vec5 vsc = rgb_to_vsc(source_mean_rgb);

    vsc.b = new_vsc.b;
    vsc.a = new_vsc.a;
    vsc.f = new_vsc.f;

    float a = ac_alpha[0];
    float c = ac_alpha[1];

    vsc.r = c * (vsc.r - mean_vs.r) + new_vsc.r;
    vsc.g = a * (vsc.g - mean_vs.g) + new_vsc.g;

    vsc.r = clamp(vsc.r, 0.f, 1.f);
    vsc.g = clamp(vsc.g, 0.f, 1.f);

    vec3 result_rgb = vsc_to_rgb(vsc);

    return mix(source_mean_rgb, result_rgb, alpha);
}

vec2 apply_prev_means(ivec2 region_mean_pos, int makeup_layer)
{
    ivec2 weights_pos = get_weights_position(makeup_layer);
    vec3 region_mean_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), region_mean_pos, 0).rgb;
    float weights_sum = texelFetch(BNB_SAMPLER_2D(tex_weights), weights_pos, 0).r;
    vec3 result_mean = region_mean_rgb * weights_sum;

    for (int i = 0; i < makeup_layer; i++) {
        float prev_layer_weight = texelFetch(BNB_SAMPLER_2D(tex_weights), weights_pos + ivec2(i + 1, 0), 0).r;
        vec3 updated_mean = update_mean(region_mean_rgb, makeup_vsc[i], result_means_vs[i], makeup_ac_alpha[i]);
        float weight = prev_layer_weight * result_weights_sum[i];

        result_mean += updated_mean * weight;
        weights_sum += weight;
    }

    result_mean += (1.f - weights_sum) * region_mean_rgb;
    result_means_rgb[makeup_layer] = result_mean;
    result_means_vs[makeup_layer] = rgb_to_vs(result_mean);
    result_weights_sum[makeup_layer] = 1.f;

    return result_means_vs[makeup_layer];
}

vec2 make_mean(int makeup_layer)
{
    /* makeup layer is disabled and region_mean_rgb has no value. attempt to make current layer mean by previous layers */
    ivec2 weights_pos = get_weights_position(makeup_layer);
    vec3 result_mean = vec3(0.f);
    float result_weight = 0.f;

    for (int i = 0; i < makeup_layer; i++) {
        float prev_layer_weight = texelFetch(BNB_SAMPLER_2D(tex_weights), weights_pos + ivec2(i + 1, 0), 0).r;
        result_mean += result_means_rgb[i] * result_weights_sum[i] * prev_layer_weight;
        result_weight += result_weights_sum[i] * prev_layer_weight;
    }
    result_means_rgb[makeup_layer] = result_mean;
    result_means_vs[makeup_layer] = rgb_to_vs(result_mean);
    result_weights_sum[makeup_layer] = result_weight;

    return result_means_vs[makeup_layer];
}

vec2 apply_means(ivec2 region_mean_pos, int makeup_layer)
{
    bool is_enabled = makeup_ac_alpha[makeup_layer][2] > 0.f;
    return is_enabled ? apply_prev_means(region_mean_pos, makeup_layer) : make_mean(makeup_layer);
}

void main()
{
#ifdef BNB_MAKEUP_FOUNDATION
    /* Use full frame for render. Foundation may color head of bald people, so box can't cover it. */
    vec2 v = attrib_pos.xy;
    gl_Position = vec4(v, 0., 1.);
#else
    /* use face box for render instead of a full frame. */
    vec2 v = attrib_pos.xy * vec2(1., 1.2) - vec2(0., 0.2);
    v = v * 0.5 + 0.5;
    mat3 face_rect_mat = mat3(bnb_FACE_RECT[0].xyz, bnb_FACE_RECT[1].xyz, bnb_FACE_RECT[2].xyz);
    gl_Position = vec4((vec3(v, 1.f) * bnb_inverse_trs2d(face_rect_mat)).xy, 0., 1.);
#endif

    var_uv = gl_Position.xy * 0.5 + 0.5;

#ifdef BNB_VK_1
    var_uv.y = 1. - var_uv.y;
#endif

#ifdef BNB_MAKEUP_LIPS_GLOSS
    lips_gloss_chameleon_uv.xy = (vec3(gl_Position.xy, 1.f) * mat3(lips_gloss_nn_transform)).xy;
#endif

#ifdef BNB_MAKEUP_LIPS_CHAMELEON
    lips_gloss_chameleon_uv.zw = (vec3(gl_Position.xy, 1.f) * mat3(lips_chameleon_nn_transform)).xy;
#endif

#ifdef BNB_MAKEUP_EYELIDS_GLOSS
    eyelids_gloss_chameleon_uv.xy = (vec3(gl_Position.xy, 1.f) * mat3(eyelids_gloss_nn_transform)).xy;
#endif

#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON
    eyelids_gloss_chameleon_uv.zw = (vec3(gl_Position.xy, 1.f) * mat3(eyelids_chameleon_nn_transform)).xy;
#endif

    fill_makeups_data(BNB_PASS_SAMPLER_ARGUMENT(tex_makeup_colors)); /* makeup_params.glsl */

    /* prepare all required means */
    int makeup_layer = 0;
#ifdef BNB_MAKEUP_FOUNDATION_MEAN
    mean_foundation = apply_means(BNB_SKIN_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_CONCEALER_MEAN
    mean_concealer = apply_means(BNB_CONCEALER_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_CONTOUR_MEAN
    mean_contour = apply_means(BNB_CONTOUR_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_HIGHLIGHTER_MEAN
    mean_highlighter = apply_means(BNB_HIGHLIGHTER_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_BLUSH_MEAN
    mean_blush = apply_means(BNB_BLUSH_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_LIPSTICK_MEAN
    mean_lipstick = apply_means(BNB_LIPS_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_LIPS_CHAMELEON_MEAN
    mean_lips_chameleon_0 = apply_means(BNB_LIPS_MEAN_LOCATION, makeup_layer);
    mean_lips_chameleon_1 = apply_means(BNB_LIPS_MEAN_LOCATION, makeup_layer + 1);
#endif
    makeup_layer += 2;

#ifdef BNB_MAKEUP_LIPSLINER_MEAN
    mean_lipsliner = apply_means(BNB_LIPSLINER_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_EYESHADOW_MEAN
    mean_eyeshadow_0 = apply_means(BNB_EYESHADOW_0_MEAN_LOCATION, makeup_layer);
    mean_eyeshadow_1 = apply_means(BNB_EYESHADOW_1_MEAN_LOCATION, makeup_layer + 1);
    mean_eyeshadow_2 = apply_means(BNB_EYESHADOW_2_MEAN_LOCATION, makeup_layer + 2);
#endif
    makeup_layer += 3;

#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON_MEAN
    mean_eyelids_chameleon_00 = apply_means(BNB_EYESHADOW_0_MEAN_LOCATION, makeup_layer);
    mean_eyelids_chameleon_01 = apply_means(BNB_EYESHADOW_1_MEAN_LOCATION, makeup_layer + 1);
    mean_eyelids_chameleon_02 = apply_means(BNB_EYESHADOW_2_MEAN_LOCATION, makeup_layer + 2);
    mean_eyelids_chameleon_10 = apply_means(BNB_EYESHADOW_0_MEAN_LOCATION, makeup_layer + 3);
    mean_eyelids_chameleon_11 = apply_means(BNB_EYESHADOW_1_MEAN_LOCATION, makeup_layer + 4);
    mean_eyelids_chameleon_12 = apply_means(BNB_EYESHADOW_2_MEAN_LOCATION, makeup_layer + 5);
#endif
    makeup_layer += 6;

#ifdef BNB_MAKEUP_EYELINER_MEAN
    mean_eyeliner = apply_means(BNB_EYELINER_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;

#ifdef BNB_MAKEUP_EYEBROWS_MEAN
    mean_eyebrows = apply_means(BNB_BROWS_MEAN_LOCATION, makeup_layer);
#endif
    makeup_layer++;


#ifdef BNB_MEANS_DEBUG
    debug_mean_skin_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), BNB_SKIN_MEAN_LOCATION, 0).rgb;
    debug_mean_brows_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_BROWS_MEAN_LOCATION, 0).rgb);
    debug_mean_lips_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_LIPS_MEAN_LOCATION, 0).rgb);
    debug_mean_lipsliner_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), BNB_LIPSLINER_MEAN_LOCATION, 0).rgb;
    debug_mean_concealer_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_CONCEALER_MEAN_LOCATION, 0).rgb);
    debug_mean_contour_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), BNB_CONTOUR_MEAN_LOCATION, 0).rgb;
    debug_mean_highlighter_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), BNB_HIGHLIGHTER_MEAN_LOCATION, 0).rgb;
    debug_mean_blush_rgb = texelFetch(BNB_SAMPLER_2D(tex_means), BNB_BLUSH_MEAN_LOCATION, 0).rgb;
    debug_mean_shadow_0_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_EYESHADOW_0_MEAN_LOCATION, 0).rgb);
    debug_mean_shadow_1_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_EYESHADOW_1_MEAN_LOCATION, 0).rgb);
    debug_mean_shadow_2_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_EYESHADOW_2_MEAN_LOCATION, 0).rgb);
    debug_mean_eyeliner_rgb = (texelFetch(BNB_SAMPLER_2D(tex_means), BNB_EYELINER_MEAN_LOCATION, 0).rgb);
#endif
}
