/* For additional information please read banuba_sdk/misc/one_stage_makeup/README.md */

#include <bnb/glsl.frag>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"
#include "bnb_prefabs/makeup_base/shaders/coloring.glsl"

BNB_IN(0)
vec2 var_uv;
BNB_IN(1)
vec4 lips_gloss_chameleon_uv;
BNB_IN(2)
vec4 eyelids_gloss_chameleon_uv;

flat BNB_IN(3) vec2 mean_foundation;
flat BNB_IN(4) vec2 mean_concealer;
flat BNB_IN(5) vec2 mean_contour;
flat BNB_IN(6) vec2 mean_highlighter;
flat BNB_IN(7) vec2 mean_blush;
flat BNB_IN(8) vec2 mean_lipstick;
flat BNB_IN(9) vec2 mean_lips_chameleon_0;
flat BNB_IN(10) vec2 mean_lips_chameleon_1;
flat BNB_IN(11) vec2 mean_lipsliner;
flat BNB_IN(12) vec2 mean_eyeshadow_0;
flat BNB_IN(13) vec2 mean_eyeshadow_1;
flat BNB_IN(14) vec2 mean_eyeshadow_2;
flat BNB_IN(15) vec2 mean_eyelids_chameleon_00;
flat BNB_IN(16) vec2 mean_eyelids_chameleon_01;
flat BNB_IN(17) vec2 mean_eyelids_chameleon_02;
flat BNB_IN(18) vec2 mean_eyelids_chameleon_10;
flat BNB_IN(19) vec2 mean_eyelids_chameleon_11;
flat BNB_IN(20) vec2 mean_eyelids_chameleon_12;
flat BNB_IN(21) vec2 mean_eyeliner;
flat BNB_IN(22) vec2 mean_eyebrows;

#ifdef BNB_MEANS_DEBUG
flat BNB_IN(23) vec3 debug_mean_skin_rgb;
flat BNB_IN(24) vec3 debug_mean_brows_rgb;
flat BNB_IN(25) vec3 debug_mean_lips_rgb;
flat BNB_IN(26) vec3 debug_mean_lipsliner_rgb;
flat BNB_IN(27) vec3 debug_mean_concealer_rgb;
flat BNB_IN(28) vec3 debug_mean_contour_rgb;
flat BNB_IN(29) vec3 debug_mean_highlighter_rgb;
flat BNB_IN(30) vec3 debug_mean_blush_rgb;
flat BNB_IN(31) vec3 debug_mean_shadow_0_rgb;
flat BNB_IN(32) vec3 debug_mean_shadow_1_rgb;
flat BNB_IN(33) vec3 debug_mean_shadow_2_rgb;
flat BNB_IN(34) vec3 debug_mean_eyeliner_rgb;
#endif

BNB_DECLARE_SAMPLER_2D(0, 1, tex_makeup_colors);
BNB_DECLARE_SAMPLER_2D(6, 7, tex_source);
BNB_DECLARE_SAMPLER_2D(8, 9, tex_blurred);
BNB_DECLARE_SAMPLER_2D(10, 11, tex_mean);
BNB_DECLARE_SAMPLER_2D(12, 13, skin_brows_lips_nn);
BNB_DECLARE_SAMPLER_2D(14, 15, concealer_contour_highlighter_blush_tex_c);
BNB_DECLARE_SAMPLER_2D(16, 17, shadows_eyeliner_tex_c);
BNB_DECLARE_SAMPLER_2D(18, 19, lips_gloss);
BNB_DECLARE_SAMPLER_2D(20, 21, lips_chameleon);
BNB_DECLARE_SAMPLER_2D(22, 23, eyelids_gloss);
BNB_DECLARE_SAMPLER_2D(24, 25, eyelids_chameleon);

void main()
{
    vec4 source_rgb = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_source), var_uv);
    vec3 rgb = source_rgb.rgb;
    vec3 blurred_rgb = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_blurred), var_uv).rgb;

    vec4 skin_brows_lips_lipsliner = BNB_TEXTURE_2D(BNB_SAMPLER_2D(skin_brows_lips_nn), var_uv);
    vec4 concealer_contour_highlighter_blush = BNB_TEXTURE_2D(BNB_SAMPLER_2D(concealer_contour_highlighter_blush_tex_c), var_uv);
    vec4 shadows_eyeliner = BNB_TEXTURE_2D(BNB_SAMPLER_2D(shadows_eyeliner_tex_c), var_uv);

    /* prepare blurred image */
    float smooth_val = 0.f;
#ifdef BNB_MAKEUP_FOUNDATION
    smooth_val = process_smooth(smooth_val, foundation_krp, skin_brows_lips_lipsliner[0]);
#endif
#ifdef BNB_MAKEUP_CONCEALER
    smooth_val = process_smooth(smooth_val, concealer_krp, concealer_contour_highlighter_blush[0]);
#endif
#ifdef BNB_MAKEUP_CONTOUR
    smooth_val = process_smooth(smooth_val, contour_krp, concealer_contour_highlighter_blush[1]);
#endif
#ifdef BNB_MAKEUP_HIGHLIGHTER // order: 115
    smooth_val = process_smooth(smooth_val, highlighter_krp, concealer_contour_highlighter_blush[2]);
#endif
#ifdef BNB_MAKEUP_BLUSH // order: 120
    smooth_val = process_smooth(smooth_val, blush_krp, concealer_contour_highlighter_blush[3]);
#endif
#ifdef BNB_MAKEUP_LIPSTICK // order: 125
    smooth_val = process_smooth(smooth_val, lipstick_krp, skin_brows_lips_lipsliner[2]);
#endif
#ifdef BNB_MAKEUP_LIPS_CHAMELEON // order: 127
    float lips_chameleon_smooth0 = process_smooth(smooth_val, lipschameleon_0_krp, skin_brows_lips_lipsliner[2]);
    float lips_chameleon_smooth1 = process_smooth(smooth_val, lipschameleon_1_krp, skin_brows_lips_lipsliner[2]);
    float lips_chameleon_mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(lips_chameleon), lips_gloss_chameleon_uv.zw).r;

    smooth_val = mix(lips_chameleon_smooth0, lips_chameleon_smooth1, lips_chameleon_mask);
#endif
#ifdef BNB_MAKEUP_LIPSLINER // order: 130
    smooth_val = process_smooth(smooth_val, lipsliner_krp, skin_brows_lips_lipsliner[3]);
#endif
#ifdef BNB_MAKEUP_EYESHADOW // order: 135
    smooth_val = process_smooth(smooth_val, eyeshadow0_krp, shadows_eyeliner[0]);
    smooth_val = process_smooth(smooth_val, eyeshadow1_krp, shadows_eyeliner[1]);
    smooth_val = process_smooth(smooth_val, eyeshadow2_krp, shadows_eyeliner[2]);
#endif
#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON // order: 137
    float eyelids_chameleon_smooth0 = smooth_val;
    eyelids_chameleon_smooth0 = process_smooth(eyelids_chameleon_smooth0, eyelids_chameleon_00_krp, shadows_eyeliner[0]);
    eyelids_chameleon_smooth0 = process_smooth(eyelids_chameleon_smooth0, eyelids_chameleon_01_krp, shadows_eyeliner[1]);
    eyelids_chameleon_smooth0 = process_smooth(eyelids_chameleon_smooth0, eyelids_chameleon_02_krp, shadows_eyeliner[2]);

    float eyelids_chameleon_mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyelids_chameleon), eyelids_gloss_chameleon_uv.zw).r;

    float eyelids_chameleon_smooth1 = smooth_val;
    eyelids_chameleon_smooth1 = process_smooth(eyelids_chameleon_smooth1, eyelids_chameleon_10_krp, shadows_eyeliner[0]);
    eyelids_chameleon_smooth1 = process_smooth(eyelids_chameleon_smooth1, eyelids_chameleon_11_krp, shadows_eyeliner[1]);
    eyelids_chameleon_smooth1 = process_smooth(eyelids_chameleon_smooth1, eyelids_chameleon_12_krp, shadows_eyeliner[2]);

    smooth_val = mix(eyelids_chameleon_smooth0, eyelids_chameleon_smooth1, eyelids_chameleon_mask);
#endif
#ifdef BNB_MAKEUP_EYELINER // order: 140
    smooth_val = process_smooth(smooth_val, eyeliner_krp, shadows_eyeliner[3]);
#endif
#ifdef BNB_MAKEUP_EYEBROWS // order: 145
    smooth_val = process_smooth(smooth_val, eyebrows_krp, skin_brows_lips_lipsliner[1]);
#endif
    rgb = mix(rgb, blurred_rgb, smooth_val);

    /* coloring */
#ifdef BNB_MAKEUP_FOUNDATION // order: 100
    vec4 foundation_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_FOUNDATION_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_foundation, foundation_rgba, foundation_krp, foundation_abcd, skin_brows_lips_lipsliner[0]
    );
#endif

#ifdef BNB_MAKEUP_CONCEALER // order: 105
    vec4 concealer_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_CONCEALER_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_concealer, concealer_rgba, concealer_krp, concealer_abcd, concealer_contour_highlighter_blush[0]
    );
#endif

#ifdef BNB_MAKEUP_CONTOUR // order: 110
    vec4 contour_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_CONTOUR_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_contour, contour_rgba, contour_krp, contour_abcd, concealer_contour_highlighter_blush[1]
    );
#endif

#ifdef BNB_MAKEUP_HIGHLIGHTER // order: 115
    vec4 highlighter_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_HIGHLIGHTER_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_highlighter, highlighter_rgba, highlighter_krp, highlighter_abcd, concealer_contour_highlighter_blush[2]
    );
#endif

#ifdef BNB_MAKEUP_BLUSH // order: 120
    vec4 blush_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_BLUSH_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_blush, blush_rgba, blush_krp, blush_abcd, concealer_contour_highlighter_blush[3]
    );
#endif

#ifdef BNB_MAKEUP_LIPSTICK // order: 125
    vec4 lipstick_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_LIPSTICK_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_lipstick, lipstick_rgba, lipstick_krp, lipstick_abcd, skin_brows_lips_lipsliner[2]
    );
#endif

#ifdef BNB_MAKEUP_LIPS_CHAMELEON // order: 127
    vec4 lips_chameleon_0_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_LIPS_CHAMELEON_0_RGB_LOCATION, 0);
    vec4 lips_chameleon_1_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_LIPS_CHAMELEON_1_RGB_LOCATION, 0);

    vec3 lips_chameleon_rgb_0 = process_pixel(
        rgb, mean_lips_chameleon_0, lips_chameleon_0_rgba, lipschameleon_0_krp, lipschameleon_0_abcd, skin_brows_lips_lipsliner[2]
    );
    vec3 lips_chameleon_rgb_1 = process_pixel(
        rgb, mean_lips_chameleon_1, lips_chameleon_1_rgba, lipschameleon_1_krp, lipschameleon_1_abcd, skin_brows_lips_lipsliner[2]
    );
    rgb = mix(lips_chameleon_rgb_0, lips_chameleon_rgb_1, lips_chameleon_mask);
#endif

#ifdef BNB_MAKEUP_LIPS_GLOSS // order: 129
    float lips_gloss_mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(lips_gloss), lips_gloss_chameleon_uv.xy).r;
    lips_gloss_mask *= skin_brows_lips_lipsliner[2];
    rgb = process_gloss_pixel(rgb, lips_gloss_params, lips_gloss_mask);
#endif

#ifdef BNB_MAKEUP_LIPSLINER // order: 130
    vec4 lipsliner_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_LIPSLINER_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_lipsliner, lipsliner_rgba, lipsliner_krp, lipsliner_abcd, skin_brows_lips_lipsliner[3]
    );
#endif

#ifdef BNB_MAKEUP_EYESHADOW // order: 135
    vec4 eyeshadow_0_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYESHADOW_0_RGB_LOCATION, 0);
    vec4 eyeshadow_1_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYESHADOW_1_RGB_LOCATION, 0);
    vec4 eyeshadow_2_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYESHADOW_2_RGB_LOCATION, 0);

    rgb = process_pixel(
        rgb, mean_eyeshadow_0, eyeshadow_0_rgba, eyeshadow0_krp, eyeshadow0_abcd, shadows_eyeliner[0]
    );
    rgb = process_pixel(
        rgb, mean_eyeshadow_1, eyeshadow_1_rgba, eyeshadow1_krp, eyeshadow1_abcd, shadows_eyeliner[1]
    );
    rgb = process_pixel(
        rgb, mean_eyeshadow_2, eyeshadow_2_rgba, eyeshadow2_krp, eyeshadow2_abcd, shadows_eyeliner[2]
    );
#endif

#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON // order: 137
    /* lower layer */
    vec4 eyelids_chameleon_00_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_00_RGB_LOCATION, 0);
    vec4 eyelids_chameleon_01_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_01_RGB_LOCATION, 0);
    vec4 eyelids_chameleon_02_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_02_RGB_LOCATION, 0);

    vec3 eyelids_chameleon_rgb_0 = rgb;
    eyelids_chameleon_rgb_0 = process_pixel(
        eyelids_chameleon_rgb_0, mean_eyelids_chameleon_00, eyelids_chameleon_00_rgba, eyelids_chameleon_00_krp, eyelids_chameleon_00_abcd, shadows_eyeliner[0]
    );
    eyelids_chameleon_rgb_0 = process_pixel(
        eyelids_chameleon_rgb_0, mean_eyelids_chameleon_01, eyelids_chameleon_01_rgba, eyelids_chameleon_01_krp, eyelids_chameleon_01_abcd, shadows_eyeliner[1]
    );
    eyelids_chameleon_rgb_0 = process_pixel(
        eyelids_chameleon_rgb_0, mean_eyelids_chameleon_02, eyelids_chameleon_02_rgba, eyelids_chameleon_02_krp, eyelids_chameleon_02_abcd, shadows_eyeliner[2]
    );

    /* upper layer */
    vec4 eyelids_chameleon_10_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_10_RGB_LOCATION, 0);
    vec4 eyelids_chameleon_11_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_11_RGB_LOCATION, 0);
    vec4 eyelids_chameleon_12_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELIDS_CHAMELEON_12_RGB_LOCATION, 0);

    vec3 eyelids_chameleon_rgb_1 = rgb;
    eyelids_chameleon_rgb_1 = process_pixel(
        eyelids_chameleon_rgb_1, mean_eyelids_chameleon_10, eyelids_chameleon_10_rgba, eyelids_chameleon_10_krp, eyelids_chameleon_10_abcd, shadows_eyeliner[0]
    );
    eyelids_chameleon_rgb_1 = process_pixel(
        eyelids_chameleon_rgb_1, mean_eyelids_chameleon_11, eyelids_chameleon_11_rgba, eyelids_chameleon_11_krp, eyelids_chameleon_11_abcd, shadows_eyeliner[1]
    );
    eyelids_chameleon_rgb_1 = process_pixel(
        eyelids_chameleon_rgb_1, mean_eyelids_chameleon_12, eyelids_chameleon_12_rgba, eyelids_chameleon_12_krp, eyelids_chameleon_12_abcd, shadows_eyeliner[2]
    );

    rgb = mix(eyelids_chameleon_rgb_0, eyelids_chameleon_rgb_1, eyelids_chameleon_mask);
#endif

#ifdef BNB_MAKEUP_EYELIDS_GLOSS // order: 139
    float eyelids_gloss_mask = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyelids_gloss), eyelids_gloss_chameleon_uv.xy).r;
    eyelids_gloss_mask *= min(1.f, shadows_eyeliner[0] + shadows_eyeliner[1] + shadows_eyeliner[2]);
    rgb = process_gloss_pixel(rgb, eyelids_gloss_params, eyelids_gloss_mask);
#endif

#ifdef BNB_MAKEUP_EYELINER // order: 140
    vec4 eyeliner_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYELINER_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_eyeliner, eyeliner_rgba, eyeliner_krp, eyeliner_abcd, shadows_eyeliner[3]
    );
#endif

#ifdef BNB_MAKEUP_EYEBROWS // order: 145
    vec4 eyebrows_rgba = texelFetch(BNB_SAMPLER_2D(tex_makeup_colors), BNB_EYEBROWS_RGB_LOCATION, 0);
    rgb = process_pixel(
        rgb, mean_eyebrows, eyebrows_rgba, eyebrows_krp, eyebrows_abcd, skin_brows_lips_lipsliner[1]
    );
#endif

    bnb_FragColor = vec4(rgb, source_rgb.a);

#ifdef BNB_MEANS_DEBUG
    if (gl_FragCoord.x > 0.f && gl_FragCoord.x < 200.f && gl_FragCoord.y > 0.f && gl_FragCoord.y < 200.f)
        bnb_FragColor = vec4(debug_mean_skin_rgb, 1.f);
    else if (gl_FragCoord.x > 200.f && gl_FragCoord.x < 400.f && gl_FragCoord.y > 0.f && gl_FragCoord.y < 200.f)
        bnb_FragColor = vec4(debug_mean_brows_rgb, 1.f);
    else if (gl_FragCoord.x > 400.f && gl_FragCoord.x < 600.f && gl_FragCoord.y > 0.f && gl_FragCoord.y < 200.f)
        bnb_FragColor = vec4(debug_mean_lips_rgb, 1.f);
    else if (gl_FragCoord.x > 600.f && gl_FragCoord.x < 800.f && gl_FragCoord.y > 0.f && gl_FragCoord.y < 200.f)
        bnb_FragColor = vec4(debug_mean_lipsliner_rgb, 1.f);
    else if (gl_FragCoord.x > 0 && gl_FragCoord.x < 200.f && gl_FragCoord.y > 200.f && gl_FragCoord.y < 400.f)
        bnb_FragColor = vec4(debug_mean_concealer_rgb, 1.f);
    else if (gl_FragCoord.x > 200.f && gl_FragCoord.x < 400.f && gl_FragCoord.y > 200.f && gl_FragCoord.y < 400.f)
        bnb_FragColor = vec4(debug_mean_contour_rgb, 1.f);
    else if (gl_FragCoord.x > 400.f && gl_FragCoord.x < 600.f && gl_FragCoord.y > 200.f && gl_FragCoord.y < 400.f)
        bnb_FragColor = vec4(debug_mean_highlighter_rgb, 1.f);
    else if (gl_FragCoord.x > 600.f && gl_FragCoord.x < 800.f && gl_FragCoord.y > 200.f && gl_FragCoord.y < 400.f)
        bnb_FragColor = vec4(debug_mean_blush_rgb, 1.f);
    else if (gl_FragCoord.x > 0 && gl_FragCoord.x < 200.f && gl_FragCoord.y > 400.f && gl_FragCoord.y < 600.f)
        bnb_FragColor = vec4(debug_mean_shadow_0_rgb, 1.f);
    else if (gl_FragCoord.x > 200.f && gl_FragCoord.x < 400.f && gl_FragCoord.y > 400.f && gl_FragCoord.y < 600.f)
        bnb_FragColor = vec4(debug_mean_shadow_1_rgb, 1.f);
    else if (gl_FragCoord.x > 400.f && gl_FragCoord.x < 600.f && gl_FragCoord.y > 400.f && gl_FragCoord.y < 600.f)
        bnb_FragColor = vec4(debug_mean_shadow_2_rgb, 1.f);
    else if (gl_FragCoord.x > 600.f && gl_FragCoord.x < 800.f && gl_FragCoord.y > 400.f && gl_FragCoord.y < 600.f)
        bnb_FragColor = vec4(debug_mean_eyeliner_rgb, 1.f);
#endif
}
