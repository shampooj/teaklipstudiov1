#include <bnb/glsl.frag>
#include <bnb/color_spaces.glsl>

BNB_IN(0)
vec2 var_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, tex_input);
BNB_DECLARE_SAMPLER_2D(2, 3, tex_mask);

layout(location = 1) out vec4 bnb_FragColor1;
layout(location = 2) out vec4 bnb_FragColor2;
layout(location = 3) out vec4 bnb_FragColor3;

void main()
{
    vec4 rgba = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_input), var_uv);
    vec4 masks = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_mask), var_uv);

    masks = step(vec4(0.5), masks);

    bnb_FragColor = vec4(rgba.rgb * masks.r, masks.r);
    bnb_FragColor1 = vec4(rgba.rgb * masks.g, masks.g);
    bnb_FragColor2 = vec4(rgba.rgb * masks.b, masks.b);
    bnb_FragColor3 = vec4(rgba.rgb * masks.a, masks.a);
}
