#include <bnb/glsl.vert>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"

BNB_LAYOUT_LOCATION(0)
BNB_IN vec2 attrib_pos;

BNB_OUT(0)
vec2 var_uv;

flat BNB_OUT(1) vec3 means[BNB_MEANS_AMOUNT];

BNB_DECLARE_SAMPLER_2D(0, 1, mean_0);
BNB_DECLARE_SAMPLER_2D(2, 3, mean_1);
BNB_DECLARE_SAMPLER_2D(4, 5, mean_2);
BNB_DECLARE_SAMPLER_2D(6, 7, mean_3);
BNB_DECLARE_SAMPLER_2D(8, 9, mean_4);
BNB_DECLARE_SAMPLER_2D(10, 11, mean_5);
BNB_DECLARE_SAMPLER_2D(12, 13, mean_6);
BNB_DECLARE_SAMPLER_2D(14, 15, mean_7);
BNB_DECLARE_SAMPLER_2D(16, 17, mean_8);
BNB_DECLARE_SAMPLER_2D(18, 19, mean_9);
BNB_DECLARE_SAMPLER_2D(20, 21, mean_10);
BNB_DECLARE_SAMPLER_2D(22, 23, mean_11);

void main()
{
    vec2 v = attrib_pos.xy;
    gl_Position = vec4(v, 0., 1.);
    var_uv = v * 0.5 + 0.5;

#ifdef BNB_VK_1
    var_uv.y = 1. - var_uv.y;
#endif

    vec4 means_rgba[BNB_MEANS_AMOUNT];
    means_rgba[0] = texelFetch(BNB_SAMPLER_2D(mean_0), ivec2(0, 0), 8);
    means_rgba[1] = texelFetch(BNB_SAMPLER_2D(mean_1), ivec2(0, 0), 8);
    means_rgba[2] = texelFetch(BNB_SAMPLER_2D(mean_2), ivec2(0, 0), 8);
    means_rgba[3] = texelFetch(BNB_SAMPLER_2D(mean_3), ivec2(0, 0), 8);
    means_rgba[4] = texelFetch(BNB_SAMPLER_2D(mean_4), ivec2(0, 0), 8);
    means_rgba[5] = texelFetch(BNB_SAMPLER_2D(mean_5), ivec2(0, 0), 8);
    means_rgba[6] = texelFetch(BNB_SAMPLER_2D(mean_6), ivec2(0, 0), 8);
    means_rgba[7] = texelFetch(BNB_SAMPLER_2D(mean_7), ivec2(0, 0), 8);
    means_rgba[8] = texelFetch(BNB_SAMPLER_2D(mean_8), ivec2(0, 0), 8);
    means_rgba[9] = texelFetch(BNB_SAMPLER_2D(mean_9), ivec2(0, 0), 8);
    means_rgba[10] = texelFetch(BNB_SAMPLER_2D(mean_10), ivec2(0, 0), 8);
    means_rgba[11] = texelFetch(BNB_SAMPLER_2D(mean_11), ivec2(0, 0), 8);

    for (int i = 0; i < BNB_MEANS_AMOUNT; i++) {
        means[i] = means_rgba[i].rgb / max(means_rgba[i].w, 0.00001);
    }
}
