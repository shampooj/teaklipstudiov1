#include <bnb/glsl.frag>

BNB_IN(0)
vec2 var_uv;

BNB_DECLARE_SAMPLER_2D(0, 1, img);

void main()
{
    ivec2 image_size = textureSize(BNB_SAMPLER_2D(img), 0) - 1;
    ivec2 iuv = ivec2(var_uv * vec2(image_size) + vec2(0.5f));

    vec3 blurred = texelFetch(BNB_SAMPLER_2D(img), iuv, 0).rgb;
    float mult_sum = 1.;

    int radius = 4;
    // float sigma = (float(radius) * 2. - 1.) / 4.;
    // float sigma_mult = 1. / (2. * sigma * sigma);
    float coeffs[5] = float[5](1.f, 0.8494f, 0.5204f, 0.2301f, 0.0734f);

    for (int y = 1; y <= radius; y++) {
        // coeffs[y] = exp(-sigma_mult * (x * x + y * y));
        blurred += coeffs[y] * (texelFetch(BNB_SAMPLER_2D(img), clamp(iuv + ivec2(0, y), ivec2(0), image_size), 0).rgb + texelFetch(BNB_SAMPLER_2D(img), clamp(iuv + ivec2(0, -y), ivec2(0), image_size), 0).rgb);

        mult_sum += 2.f * coeffs[y];
    }

    blurred *= 1.f / mult_sum;
    bnb_FragColor = vec4(blurred, 1.f);
}
