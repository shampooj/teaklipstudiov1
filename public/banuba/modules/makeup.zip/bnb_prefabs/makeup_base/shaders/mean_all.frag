#include <bnb/glsl.frag>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"

BNB_IN(0)
vec2 var_uv;

flat BNB_IN(1) vec3 means[BNB_MEANS_AMOUNT];

void main()
{
    int width = BNB_MEANS_TEXTURE_SIZE.x;
    int index = int(gl_FragCoord.x) + int(gl_FragCoord.y) * width;

    bnb_FragColor = index < BNB_MEANS_AMOUNT ? vec4(means[index], 1.f) : vec4(0.f);
}
