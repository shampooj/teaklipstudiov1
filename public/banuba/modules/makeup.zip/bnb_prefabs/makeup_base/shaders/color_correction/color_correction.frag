#include <bnb/glsl.frag>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"

BNB_IN(0)
vec3 foundation_rgb;
BNB_IN(1)
vec3 concealer_rgb;
BNB_IN(2)
vec3 contour_rgb;
BNB_IN(3)
vec3 highlighter_rgb;
BNB_IN(4)
vec3 blush_rgb;
BNB_IN(5)
vec3 lipstick_rgb;
BNB_IN(6)
vec3 lips_chameleon_0_rgb;
BNB_IN(7)
vec3 lips_chameleon_1_rgb;
BNB_IN(8)
vec3 lipsliner_rgb;
BNB_IN(9)
vec3 eyeshadow_0_rgb;
BNB_IN(10)
vec3 eyeshadow_1_rgb;
BNB_IN(11)
vec3 eyeshadow_2_rgb;
BNB_IN(12)
vec3 eyelids_chameleon_00_rgb;
BNB_IN(13)
vec3 eyelids_chameleon_01_rgb;
BNB_IN(14)
vec3 eyelids_chameleon_02_rgb;
BNB_IN(15)
vec3 eyelids_chameleon_10_rgb;
BNB_IN(16)
vec3 eyelids_chameleon_11_rgb;
BNB_IN(17)
vec3 eyelids_chameleon_12_rgb;
BNB_IN(18)
vec3 eyeliner_rgb;
BNB_IN(19)
vec3 eyebrows_rgb;

void main()
{
    ivec2 coords = ivec2(gl_FragCoord.xy);
    vec4 result = vec4(0.f);

#ifdef BNB_MAKEUP_FOUNDATION
    result += vec4(foundation_rgb, foundation_rgb_maxa.a) * float(coords == BNB_FOUNDATION_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_CONCEALER
    result += vec4(concealer_rgb, concealer_rgb_maxa.a) * float(coords == BNB_CONCEALER_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_CONTOUR
    result += vec4(contour_rgb, contour_rgb_maxa.a) * float(coords == BNB_CONTOUR_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_HIGHLIGHTER
    result += vec4(highlighter_rgb, highlighter_rgb_maxa.a) * float(coords == BNB_HIGHLIGHTER_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_BLUSH
    result += vec4(blush_rgb, blush_rgb_maxa.a) * float(coords == BNB_BLUSH_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_LIPSTICK
    result += vec4(lipstick_rgb, lipstick_rgb_maxa.a) * float(coords == BNB_LIPSTICK_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_LIPS_CHAMELEON
    result += vec4(lips_chameleon_0_rgb, lipschameleon_0_rgb_maxa.a) * float(coords == BNB_LIPS_CHAMELEON_0_RGB_LOCATION);
    result += vec4(lips_chameleon_1_rgb, lipschameleon_1_rgb_maxa.a) * float(coords == BNB_LIPS_CHAMELEON_1_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_LIPSLINER
    result += vec4(lipsliner_rgb, lipsliner_rgb_maxa.a) * float(coords == BNB_LIPSLINER_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_EYESHADOW
    result += vec4(eyeshadow_0_rgb, eyeshadow0_rgb_maxa.a) * float(coords == BNB_EYESHADOW_0_RGB_LOCATION);
    result += vec4(eyeshadow_1_rgb, eyeshadow1_rgb_maxa.a) * float(coords == BNB_EYESHADOW_1_RGB_LOCATION);
    result += vec4(eyeshadow_2_rgb, eyeshadow2_rgb_maxa.a) * float(coords == BNB_EYESHADOW_2_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON
    result += vec4(eyelids_chameleon_00_rgb, eyelids_chameleon_00_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_00_RGB_LOCATION);
    result += vec4(eyelids_chameleon_01_rgb, eyelids_chameleon_01_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_01_RGB_LOCATION);
    result += vec4(eyelids_chameleon_02_rgb, eyelids_chameleon_02_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_02_RGB_LOCATION);

    result += vec4(eyelids_chameleon_10_rgb, eyelids_chameleon_10_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_10_RGB_LOCATION);
    result += vec4(eyelids_chameleon_11_rgb, eyelids_chameleon_11_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_11_RGB_LOCATION);
    result += vec4(eyelids_chameleon_12_rgb, eyelids_chameleon_12_rgb_maxa.a) * float(coords == BNB_EYELIDS_CHAMELEON_12_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_EYELINER
    result += vec4(eyeliner_rgb, eyeliner_rgb_maxa.a) * float(coords == BNB_EYELINER_RGB_LOCATION);
#endif

#ifdef BNB_MAKEUP_EYEBROWS
    result += vec4(eyebrows_rgb, eyebrows_rgb_maxa.a) * float(coords == BNB_EYEBROWS_RGB_LOCATION);
#endif

    bnb_FragColor = result;
}
