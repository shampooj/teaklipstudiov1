#include <bnb/glsl.vert>
#include "bnb_prefabs/makeup_base/shaders/defines.glsl"

#define MAKEUP_FLT_MIN 0.00588f // (1.5f / 255.f)

BNB_LAYOUT_LOCATION(0)
BNB_IN vec3 attrib_pos;

BNB_DECLARE_SAMPLER_2D(0, 1, s_means);

BNB_OUT(0)
vec3 foundation_rgb;
BNB_OUT(1)
vec3 concealer_rgb;
BNB_OUT(2)
vec3 contour_rgb;
BNB_OUT(3)
vec3 highlighter_rgb;
BNB_OUT(4)
vec3 blush_rgb;
BNB_OUT(5)
vec3 lipstick_rgb;
BNB_OUT(6)
vec3 lips_chameleon_0_rgb;
BNB_OUT(7)
vec3 lips_chameleon_1_rgb;
BNB_OUT(8)
vec3 lipsliner_rgb;
BNB_OUT(9)
vec3 eyeshadow_0_rgb;
BNB_OUT(10)
vec3 eyeshadow_1_rgb;
BNB_OUT(11)
vec3 eyeshadow_2_rgb;
BNB_OUT(12)
vec3 eyelids_chameleon_00_rgb;
BNB_OUT(13)
vec3 eyelids_chameleon_01_rgb;
BNB_OUT(14)
vec3 eyelids_chameleon_02_rgb;
BNB_OUT(15)
vec3 eyelids_chameleon_10_rgb;
BNB_OUT(16)
vec3 eyelids_chameleon_11_rgb;
BNB_OUT(17)
vec3 eyelids_chameleon_12_rgb;
BNB_OUT(18)
vec3 eyeliner_rgb;
BNB_OUT(19)
vec3 eyebrows_rgb;

vec3 correct_color(vec3 new_rgb, vec3 mean_rgb, vec2 tq)
{
    float mean_v = max(max(mean_rgb.r, mean_rgb.g), mean_rgb.b);
    float new_v = max(max(new_rgb.r, new_rgb.g), new_rgb.b);
    new_v = new_v > MAKEUP_FLT_MIN ? new_v : 1.0;

    if (new_v <= mean_v)
        return new_rgb;

    float k = pow(mean_v / new_v, tq[0]);
    float w1 = 1.f - k;
    float w2 = new_rgb.r / new_v;
    float w = w1 * w2 * tq[1];
    vec3 result = new_rgb * k * (1.f - w) + vec3(new_v * k * w, 0.f, 0.f);

    return result;
}

void main()
{
    gl_Position = vec4(attrib_pos.xy, 0.f, 1.f);

    vec2 default_tq = vec2(1.f, 0.f);

#ifdef BNB_MAKEUP_FOUNDATION
    vec3 foundation_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_SKIN_MEAN_LOCATION, 0).rgb;
    foundation_rgb = correct_color(foundation_rgb_maxa.rgb, foundation_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_CONCEALER
    vec3 concealer_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_CONCEALER_MEAN_LOCATION, 0).rgb;
    concealer_rgb = correct_color(concealer_rgb_maxa.rgb, concealer_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_CONTOUR
    vec3 contour_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_CONTOUR_MEAN_LOCATION, 0).rgb;
    contour_rgb = correct_color(contour_rgb_maxa.rgb, contour_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_HIGHLIGHTER
    vec3 highlighter_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_HIGHLIGHTER_MEAN_LOCATION, 0).rgb;
    highlighter_rgb = correct_color(highlighter_rgb_maxa.rgb, highlighter_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_BLUSH
    vec3 blush_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_BLUSH_MEAN_LOCATION, 0).rgb;
    blush_rgb = correct_color(blush_rgb_maxa.rgb, blush_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_LIPSTICK
    vec3 lipstick_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_LIPS_MEAN_LOCATION, 0).rgb;
    lipstick_rgb = correct_color(lipstick_rgb_maxa.rgb, lipstick_mean_rgb, lipstick_tq.xy);
#endif

#ifdef BNB_MAKEUP_LIPS_CHAMELEON
    vec3 lips_chameleon_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_LIPS_MEAN_LOCATION, 0).rgb;
    lips_chameleon_0_rgb = correct_color(lipschameleon_0_rgb_maxa.rgb, lips_chameleon_mean_rgb, default_tq);
    lips_chameleon_1_rgb = correct_color(lipschameleon_1_rgb_maxa.rgb, lips_chameleon_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_LIPSLINER
    vec3 lipsliner_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_LIPSLINER_MEAN_LOCATION, 0).rgb;
    lipsliner_rgb = correct_color(lipsliner_rgb_maxa.rgb, lipsliner_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_EYESHADOW
    vec3 eyeshadow_0_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_0_MEAN_LOCATION, 0).rgb;
    eyeshadow_0_rgb = correct_color(eyeshadow0_rgb_maxa.rgb, eyeshadow_0_mean_rgb, eyeshadow0_tq.xy);

    vec3 eyeshadow_1_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_1_MEAN_LOCATION, 0).rgb;
    eyeshadow_1_rgb = correct_color(eyeshadow1_rgb_maxa.rgb, eyeshadow_1_mean_rgb, eyeshadow1_tq.xy);

    vec3 eyeshadow_2_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_2_MEAN_LOCATION, 0).rgb;
    eyeshadow_2_rgb = correct_color(eyeshadow2_rgb_maxa.rgb, eyeshadow_2_mean_rgb, eyeshadow2_tq.xy);
#endif

#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON
    vec3 eyelids_chameleon_0_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_0_MEAN_LOCATION, 0).rgb;
    vec3 eyelids_chameleon_1_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_1_MEAN_LOCATION, 0).rgb;
    vec3 eyelids_chameleon_2_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYESHADOW_1_MEAN_LOCATION, 0).rgb;

    eyelids_chameleon_00_rgb = correct_color(eyelids_chameleon_00_rgb_maxa.rgb, eyelids_chameleon_0_mean_rgb, default_tq);
    eyelids_chameleon_01_rgb = correct_color(eyelids_chameleon_01_rgb_maxa.rgb, eyelids_chameleon_1_mean_rgb, default_tq);
    eyelids_chameleon_02_rgb = correct_color(eyelids_chameleon_02_rgb_maxa.rgb, eyelids_chameleon_2_mean_rgb, default_tq);

    eyelids_chameleon_10_rgb = correct_color(eyelids_chameleon_10_rgb_maxa.rgb, eyelids_chameleon_0_mean_rgb, default_tq);
    eyelids_chameleon_11_rgb = correct_color(eyelids_chameleon_11_rgb_maxa.rgb, eyelids_chameleon_1_mean_rgb, default_tq);
    eyelids_chameleon_12_rgb = correct_color(eyelids_chameleon_12_rgb_maxa.rgb, eyelids_chameleon_2_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_EYELINER
    vec3 eyeliner_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_EYELINER_MEAN_LOCATION, 0).rgb;
    eyeliner_rgb = correct_color(eyeliner_rgb_maxa.rgb, eyeliner_mean_rgb, default_tq);
#endif

#ifdef BNB_MAKEUP_EYEBROWS
    vec3 eyebrows_mean_rgb = texelFetch(BNB_SAMPLER_2D(s_means), BNB_BROWS_MEAN_LOCATION, 0).rgb;
    eyebrows_rgb = correct_color(eyebrows_rgb_maxa.rgb, eyebrows_mean_rgb, default_tq);
#endif
}
