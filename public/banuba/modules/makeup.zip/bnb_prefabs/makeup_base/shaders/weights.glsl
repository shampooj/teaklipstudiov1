/* For additional information please read banuba_sdk/misc/one_stage_makeup/README.md */

#ifndef BNB_MAKEUP_WEIGHTS_GLSL
#define BNB_MAKEUP_WEIGHTS_GLSL

ivec2 smokey_base_offset = ivec2(0, 11);
ivec2 smokey_sub_offset = ivec2(0, 9);

/* is makeup layer depends from smokey param  */
int smokey_dependency[20] = int[20](
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0
);

ivec2 get_weights_position(int layer_index)
{
    /* smokey = [0...4] */
    int smokey_idx = int(smokey_eyes_index.x);
    int depends_from_smokey = smokey_dependency[layer_index] * int(bool(smokey_idx));

    return ivec2(0, layer_index) + depends_from_smokey * (smokey_base_offset + (smokey_idx - 1) * smokey_sub_offset);
}

/* old GLSL compilers do not support "\", so use one-line defines */
#if defined(BNB_MAKEUP_FOUNDATION) || defined(BNB_MAKEUP_CONCEALER) || defined(BNB_MAKEUP_CONTOUR) || defined(BNB_MAKEUP_HIGHLIGHTER) || defined(BNB_MAKEUP_BLUSH) || defined(BNB_MAKEUP_LIPSLINER) || defined(BNB_MAKEUP_EYESHADOW) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_FOUNDATION_MEAN
#endif

#if defined(BNB_MAKEUP_CONCEALER) || defined(BNB_MAKEUP_HIGHLIGHTER) || defined(BNB_MAKEUP_BLUSH) || defined(BNB_MAKEUP_EYESHADOW) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_CONCEALER_MEAN
#endif

#if defined(BNB_MAKEUP_CONTOUR) || defined(BNB_MAKEUP_HIGHLIGHTER) || defined(BNB_MAKEUP_BLUSH) || defined(BNB_MAKEUP_EYESHADOW) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_CONTOUR_MEAN
#endif

#if defined(BNB_MAKEUP_HIGHLIGHTER) || defined(BNB_MAKEUP_BLUSH) || defined(BNB_MAKEUP_EYESHADOW) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_HIGHLIGHTER_MEAN
#endif

#if defined(BNB_MAKEUP_BLUSH) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_BLUSH_MEAN
#endif

#if defined(BNB_MAKEUP_LIPSTICK) || defined(BNB_MAKEUP_LIPS_CHAMELEON)
    #define BNB_MAKEUP_LIPSTICK_MEAN
#endif

#if defined(BNB_MAKEUP_LIPS_CHAMELEON)
    #define BNB_MAKEUP_LIPS_CHAMELEON_MEAN
#endif

#if defined(BNB_MAKEUP_LIPSLINER)
    #define BNB_MAKEUP_LIPSLINER_MEAN
#endif

#if defined(BNB_MAKEUP_EYESHADOW) || defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_EYESHADOW_MEAN
#endif

#if defined(BNB_MAKEUP_EYELIDS_CHAMELEON) || defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_EYELIDS_CHAMELEON_MEAN
#endif

#if defined(BNB_MAKEUP_EYELINER)
    #define BNB_MAKEUP_EYELINER_MEAN
#endif

#if defined(BNB_MAKEUP_EYEBROWS)
    #define BNB_MAKEUP_EYEBROWS_MEAN
#endif

#endif
