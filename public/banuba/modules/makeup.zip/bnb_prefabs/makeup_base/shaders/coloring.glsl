#include <bnb/color_spaces.glsl>

#define MAKEUP_FLT_MIN 0.00588f // (1.5f / 255.f)

float process_smooth(float prev_smooth, vec4 krpw, float mask)
{
    float new_smooth = 0.5f * krpw[1] * krpw[2];
    float alpha = krpw[0] * krpw[3] * mask;
    return mix(prev_smooth, new_smooth, alpha);
}

vec3 color_pixel(vec3 source_rgb, vec3 new_rgb, vec2 mean_vs, vec2 ac)
{
    vec5 vsc = rgb_to_vsc(source_rgb);
    vec5 new_vsc = rgb_to_vsc(new_rgb);

    vsc.b = new_vsc.b;
    vsc.a = new_vsc.a;
    vsc.f = new_vsc.f;

    float a = ac[0];
    float c = ac[1];

    vsc.r = c * (vsc.r - mean_vs.r) + new_vsc.r;
    vsc.g = a * (vsc.g - mean_vs.g) + new_vsc.g;

    vsc.r = clamp(vsc.r, 0.f, 1.f);
    vsc.g = clamp(vsc.g, 0.f, 1.f);

    vec3 result_rgb = vsc_to_rgb(vsc);

    return result_rgb;
}

vec3 process_pixel(vec3 colored_rgb, vec2 mean_vs, vec4 rgb_maxa, vec4 krpw, vec4 abcd, float mask)
{
    float alpha = mask * krpw[0] * krpw[3];

    if (alpha < MAKEUP_FLT_MIN)
        return colored_rgb;

    vec3 result_rgb = color_pixel(colored_rgb, rgb_maxa.rgb, mean_vs, vec2(abcd[0], abcd[2]));

    return mix(colored_rgb, result_rgb, alpha);
}

vec3 process_gloss_pixel(vec3 source_rgb, vec4 brightness_multiplier_saturation_alpha, float mask)
{
    float max_v = brightness_multiplier_saturation_alpha[0];
    float v_coef = brightness_multiplier_saturation_alpha[1];
    float s_coef = brightness_multiplier_saturation_alpha[2];
    float alpha = mask * brightness_multiplier_saturation_alpha[3];

    if (alpha < MAKEUP_FLT_MIN)
        return source_rgb;

    vec5 vsc = rgb_to_vsc(source_rgb);

    vsc.r = max_v * v_coef;
    vsc.g *= s_coef;

    vsc.r = clamp(vsc.r, 0.f, 1.f);
    vsc.g = clamp(vsc.g, 0.f, 1.f);

    vec3 result_rgb = vsc_to_rgb(vsc);

    return mix(source_rgb, result_rgb, alpha);
}
