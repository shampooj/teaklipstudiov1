#ifndef BNB_MAKEUP_PARAMS_GLSL
#define BNB_MAKEUP_PARAMS_GLSL

#include "bnb_prefabs/makeup_base/shaders/defines.glsl"
#include <bnb/color_spaces.glsl>

vec5 makeup_vsc[BNB_MAKEUP_MASKED_LAYERS];
vec3 makeup_ac_alpha[BNB_MAKEUP_MASKED_LAYERS] = vec3[BNB_MAKEUP_MASKED_LAYERS](
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f),
    vec3(0.f)
);

void fill_makeups_data(BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_colors))
{
    int index = 0;
#ifdef BNB_MAKEUP_FOUNDATION
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_FOUNDATION_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(foundation_abcd[0], foundation_abcd[2], foundation_krp[0] * foundation_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_CONCEALER
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_CONCEALER_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(concealer_abcd[0], concealer_abcd[2], concealer_krp[0] * concealer_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_CONTOUR
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_CONTOUR_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(contour_abcd[0], contour_abcd[2], contour_krp[0] * contour_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_HIGHLIGHTER
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_HIGHLIGHTER_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(highlighter_abcd[0], highlighter_abcd[2], highlighter_krp[0] * highlighter_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_BLUSH
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_BLUSH_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(blush_abcd[0], blush_abcd[2], blush_krp[0] * blush_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_LIPSTICK
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_LIPSTICK_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(lipstick_abcd[0], lipstick_abcd[2], lipstick_krp[0] * lipstick_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_LIPS_CHAMELEON
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_LIPS_CHAMELEON_0_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(lipschameleon_0_abcd[0], lipschameleon_0_abcd[2], lipschameleon_0_krp[0] * lipschameleon_0_krp[3]);

    makeup_vsc[index + 1] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_LIPS_CHAMELEON_1_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 1] = vec3(lipschameleon_1_abcd[0], lipschameleon_1_abcd[2], lipschameleon_1_krp[0] * lipschameleon_1_krp[3]);
#endif
    index += 2;
#ifdef BNB_MAKEUP_LIPSLINER
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_LIPSLINER_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(lipsliner_abcd[0], lipsliner_abcd[2], lipsliner_krp[0] * lipsliner_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_EYESHADOW
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYESHADOW_0_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(eyeshadow0_abcd[0], eyeshadow0_abcd[2], eyeshadow0_krp[0] * eyeshadow0_krp[3]);

    makeup_vsc[index + 1] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYESHADOW_1_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 1] = vec3(eyeshadow1_abcd[0], eyeshadow1_abcd[2], eyeshadow1_krp[0] * eyeshadow1_krp[3]);

    makeup_vsc[index + 2] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYESHADOW_2_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 2] = vec3(eyeshadow2_abcd[0], eyeshadow2_abcd[2], eyeshadow2_krp[0] * eyeshadow2_krp[3]);
#endif
    index += 3;
#ifdef BNB_MAKEUP_EYELIDS_CHAMELEON
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_00_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(eyelids_chameleon_00_abcd[0], eyelids_chameleon_00_abcd[2], eyelids_chameleon_00_krp[0] * eyelids_chameleon_00_krp[3]);

    makeup_vsc[index + 1] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_01_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 1] = vec3(eyelids_chameleon_01_abcd[0], eyelids_chameleon_01_abcd[2], eyelids_chameleon_01_krp[0] * eyelids_chameleon_01_krp[3]);

    makeup_vsc[index + 2] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_02_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 2] = vec3(eyelids_chameleon_02_abcd[0], eyelids_chameleon_02_abcd[2], eyelids_chameleon_02_krp[0] * eyelids_chameleon_02_krp[3]);

    makeup_vsc[index + 3] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_10_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 3] = vec3(eyelids_chameleon_10_abcd[0], eyelids_chameleon_10_abcd[2], eyelids_chameleon_10_krp[0] * eyelids_chameleon_10_krp[3]);

    makeup_vsc[index + 4] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_11_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 4] = vec3(eyelids_chameleon_11_abcd[0], eyelids_chameleon_11_abcd[2], eyelids_chameleon_11_krp[0] * eyelids_chameleon_11_krp[3]);

    makeup_vsc[index + 5] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELIDS_CHAMELEON_12_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index + 5] = vec3(eyelids_chameleon_12_abcd[0], eyelids_chameleon_12_abcd[2], eyelids_chameleon_12_krp[0] * eyelids_chameleon_12_krp[3]);
#endif
    index += 6;
#ifdef BNB_MAKEUP_EYELINER
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYELINER_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(eyeliner_abcd[0], eyeliner_abcd[2], eyeliner_krp[0] * eyeliner_krp[3]);
#endif
    index++;
#ifdef BNB_MAKEUP_EYEBROWS
    makeup_vsc[index] = rgb_to_vsc(texelFetch(BNB_SAMPLER_2D(tex_colors), BNB_EYEBROWS_RGB_LOCATION, 0).rgb);
    makeup_ac_alpha[index] = vec3(eyebrows_abcd[0], eyebrows_abcd[2], eyebrows_krp[0] * eyebrows_krp[3]);
#endif
    index++;
}

#endif // BNB_MAKEUP_PARAMS_GLSL
