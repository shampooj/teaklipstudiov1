const { Base } = require("bnb_js/prefabs")
const { FaceRegion, FaceRegionBase } = require("./region.js")

let modeCallbacks = [];
let isQualityMode = false;

class MakeupBase extends Base {
  constructor(faceIndex=0) {
    if (faceIndex !== 0) {
      bnb.log(`ERROR: MakeupBase prefab support only face index 0, got ${faceIndex}`)
      return
    }

    super(faceIndex)

    this._region = new FaceRegionBase("makeup_base");
    this._mode = "speed"

    const assets = bnb.scene.getAssetManager()
    this._fakeSkin = assets.findMaterial("shaders/nn_combine").findParameter("fake_skin_nn_active")
    this._smooth = assets.findMaterial("shaders/smooth/smooth").findParameter("smooth_weights")
    this._smokey = assets.findMaterial("shaders/face_tex").findParameter("smokey_eyes_index")

    this.mode()
  }

  static apply(region, { color, finish, coverage, strength }) {
    if (typeof coverage === "undefined") coverage = strength // backward compatibility with old coverage name

    const makeupRegion = region
    const regionSettings = region.settings

    const finishSettings = finish instanceof Object ? finish : regionSettings[finish]
    if (!finishSettings) {
      bnb.log(`[WARN] The finish "${finish}" does not exist in region "${region.name}"`)
      return
    }

    const { texture, K: kSettings, ...rest } = finishSettings

    let K

    if (typeof coverage === "number") K = coverage
    else if (typeof kSettings === "number") K = kSettings
    /*
     * maps
     * "l", "lo", "low" -> "low"
     * "m", "mi", "mid" -> "mid"
     * "h", "hi", "hig", "high" -> "high"
     */ else
      for (const preset of ["low", "mid", "high"])
        if (preset.startsWith(coverage)) K = kSettings[preset]
  
    makeupRegion.color(color)
    makeupRegion.parameters({ K, ...rest })
    if (texture) makeupRegion.texture(texture)
  }
    
  static addModeCallback(func) {
    modeCallbacks.push(func);
    func(isQualityMode); //call it in case mode already was changed
  }

  clear() {
    this.smooth("0 1")
    this.mode("speed")
  }

  smooth(weights) {
    const [wholeFace, underEyes] = weights.split(" ").map((c) => parseFloat(c))
    const { x, y, z, w } = this._smooth.getVector4()
    this._smooth.setVector4(new bnb.Vec4(wholeFace, underEyes, z, w))

    if (wholeFace > 0.0 || underEyes > 0.0) {
      this._region._show();
    } else {
      this._region._hide();
    }
  }

  /** @param {"speed"|"quality"} [mode] */
  mode(newMode) {      
    if (newMode) this._mode = newMode

    isQualityMode = this._mode === "quality"
    this._fakeSkin.setVector4(new bnb.Vec4(isQualityMode ? 0 : 1, 0, 0, 0))

    this._change_nns();

    /* notify all prefabs */
    for (const callback of modeCallbacks) {
      callback(isQualityMode);
    }
  }

  // smokey eyes index: 0 - disable smokey eyes, regular eyeshadow masks are used
  //                    1 - use red channel from contur_smokey_06.png for eyeshadow0 and red channel from shadows_arrows_smokey_06.png for eyeshadow1
  //                    2 - green channel from contur_smokey_06.png for eyeshadow0 and red channel from shadows_arrows_smokey_06.png for eyeshadow1
  //                    3 - blue channel from contur_smokey_06.png for eyeshadow0 and red channel from shadows_arrows_smokey_06.png for eyeshadow1
  //                    4 - alpha channel from contur_smokey_06.png for eyeshadow0 and red channel from shadows_arrows_smokey_06.png for eyeshadow1
  smokey(index) {
    this._smokey.setVector4(new bnb.Vec4(index, 0, 0, 0))
  }

  _change_nns() {
    if (this._mode === "quality") {
      /* quality mode requires skin_nn and face_nn */
      this._region._set_nns(["skin_nn", "face_nn"]);
    } else {
      /* speed mode requires lips and brows to cut them from face_nn */
      this._region._set_nns(["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn"]);
    }
  }
}

exports = {
  MakeupBase,
  FaceRegion,
  FaceRegionBase,
}
