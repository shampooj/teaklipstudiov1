const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const settings = JSON.parse(require("./settings.js"))

class MakeupHighlighter extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);
        this.region = new FaceRegion("highlighter", settings);
        MakeupBase.addModeCallback(this.onModeChanged);
    }

    setPrefabSettings(state) {
        this.clear()
        MakeupBase.apply(this.region, state)
    }

    onModeChanged = (isQuality) => {
        if (isQuality) {
            /* quality mode requires skin_nn and face_nn */
            this.region._set_nns(["skin_nn", "face_nn"]);
        } else {
            /* speed mode requires lips and brows to cut them from face_nn */
            this.region._set_nns(["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn"]);
        }
    }

    clear() {
        this.region.clear()
    }
}

exports = {
    MakeupHighlighter
}
