#include <bnb/glsl.frag>
#include <bnb/transform_uv.glsl>
#include "bnb_prefabs/makeup_glitter_base/shaders/glitter.glsl"

BNB_IN(0)
vec2 var_bg_uv;
BNB_IN(1)
vec2 var_eyelids_uv;
BNB_IN(2)
vec3 var_v;
flat BNB_IN(3)
    vec3 light_dir;

BNB_DECLARE_SAMPLER_2D(0, 1, camera);
BNB_DECLARE_SAMPLER_2D(2, 3, normalmap);
BNB_DECLARE_SAMPLER_2D(4, 5, eyelids_nn);
BNB_DECLARE_SAMPLER_2D(6, 7, tex_noise);
BNB_DECLARE_SAMPLER_2D(8, 9, eyeshadows_smokey);

#define FLT_EPSILON 0.004f // 1.f/255
#define LAYER0_INTENSITY 1.0
#define LAYER0_CONCENTRATION 2.0
#define LAYER1_INTENSITY 4.0
#define LAYER1_CONCENTRATION 0.3

void main()
{
    vec3 background = texelFetch(BNB_SAMPLER_2D(camera), ivec2(gl_FragCoord.xy), 0).rgb;
    float mask_alpha = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyelids_nn), var_eyelids_uv).x;
    vec4 smokey = BNB_TEXTURE_2D(BNB_SAMPLER_2D(eyeshadows_smokey), var_bg_uv);
    float smokey_mask = min(1.f, smokey.r + smokey.g + smokey.b);
    float alpha = eyelids_glitter_color_alpha.a * mask_alpha * smokey_mask;
    alpha *= bnb_get_uv_frame_alpha(var_eyelids_uv);

    if (alpha > FLT_EPSILON) {
        vec3 N = normalize(texture(BNB_SAMPLER_2D(normalmap), var_bg_uv).xyz * 2.f - 1.f);
        vec4 params = vec4(LAYER0_INTENSITY, LAYER0_CONCENTRATION, LAYER1_INTENSITY, LAYER1_CONCENTRATION);
        vec3 result = glitter_area(background, eyelids_glitter_color_alpha.rgb, alpha, N, light_dir, params, BNB_PASS_SAMPLER_ARGUMENT(tex_noise), var_v);
        bnb_FragColor = vec4(result, 1.f);
        return;
    }

    bnb_FragColor = vec4(background, 1.f);
}
