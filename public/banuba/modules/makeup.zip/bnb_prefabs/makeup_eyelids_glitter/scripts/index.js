const prefabs = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion, FaceRegionBase } = require("bnb_prefabs/makeup_base/scripts/index.js")

const default_eyelids_glitter_light_dir = new bnb.Vec4(0.5, -0.6, 0.7);

class MakeupEyelidsGlitter extends prefabs.Base {
    constructor(faceIndex = 0) {
        super(faceIndex);

        this.region = new FaceRegionBase("eyelids_glitter")

        this.cached_glitter_color_alpha = new bnb.Vec4(0, 0, 0, 0);

        const glitter_mat = bnb.scene.getAssetManager().findMaterial("eyelids_glitter_mat");
        this.glitter_color_alpha_param = glitter_mat.findParameter("eyelids_glitter_color_alpha");
        this.glitter_light_dir_param = glitter_mat.findParameter("eyelids_glitter_light_dir");

        MakeupBase.addModeCallback(this.onModeChanged);
    }
    
    onModeChanged = (isQuality) => {
        if (isQuality) {
            // quality mode requires skin_nn and face_nn
            this.region._set_nns(["skin_nn", "face_nn", "eyelids_nn"]);
        } else {
            // speed mode requires lips and brows to cut them from face_nn.
            this.region._set_nns(["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn", "eyelids_nn"]);
        }
    }

    color(value) {
        const _value = prefabs.parseColor(value);
        this.cached_glitter_color_alpha.x = _value.x;
        this.cached_glitter_color_alpha.y = _value.y;
        this.cached_glitter_color_alpha.z = _value.z;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);
    }

    alpha(value) {
        const _value = Math.min(Math.max(value, 0.0), 1.0);
        this.cached_glitter_color_alpha.w = _value;

        this.glitter_color_alpha_param.setVector4(this.cached_glitter_color_alpha);

        if (_value > 0.0)
          this.region._show();
        else
          this.region._hide();
    }

    lightDirection(vector) {
        const values = vector.split(" ").map(parseFloat);
        
        let square_sum = values[0] * values[0] + values[1] * values[1] + values[2] * values[2];
        if (square_sum > 0.01)
            this.glitter_light_dir_param.setVector4(new bnb.Vec4(values[0], values[1], values[2], 0));
        else
            this.glitter_light_dir_param.setVector4(default_eyelids_glitter_light_dir);
    }

    clear() {
        this.glitter_color_alpha_param.setVector4(prefabs.parseColor("0 0 0 0"));
        this.glitter_light_dir_param.setVector4(default_eyelids_glitter_light_dir);
        this.region._hide();
    }
}

exports = {
    MakeupEyelidsGlitter
}

