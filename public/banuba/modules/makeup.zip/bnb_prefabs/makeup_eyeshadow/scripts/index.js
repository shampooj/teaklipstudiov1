const { Base } = require("bnb_js/prefabs")
const { MakeupBase, FaceRegion } = require("bnb_prefabs/makeup_base/scripts/index.js")

const settings = JSON.parse(require("./settings.js"))

class MakeupEyeshadow extends Base {
    constructor(faceIndex=0) {
        super(faceIndex);

        this.regions = [
            new FaceRegion("eyeshadow0", settings),
            new FaceRegion("eyeshadow1", settings),
            new FaceRegion("eyeshadow2", settings),
        ];
        MakeupBase.addModeCallback(this.onModeChanged);
    }

    setPrefabSettings(state) {
        this.clear()
        if (state instanceof Array) {
            for (const [i, s] of state.entries()) {
                if (i > this.regions.length) break
                MakeupBase.apply(this.regions[i], s)
            }
        } else {
            MakeupBase.apply(this.regions[0], state)
        }
    }
    
    onModeChanged = (isQuality) => {
        if (isQuality) {
            // quality mode requires skin_nn and face_nn
            const nns = ["skin_nn", "face_nn"];
            this.regions[0]._set_nns(nns);
            this.regions[1]._set_nns(nns);
            this.regions[2]._set_nns(nns);
        } else {
            // speed mode requires lips and brows to cut them from face_nn
            const nns = ["face_nn", "lbrow_nn", "rbrow_nn", "lips_nn"];
            this.regions[0]._set_nns(nns);
            this.regions[1]._set_nns(nns);
            this.regions[2]._set_nns(nns);
        }
    }

    clear() {
        for (const region of this.regions) region.clear()
    }
}

exports = {
    MakeupEyeshadow
}
