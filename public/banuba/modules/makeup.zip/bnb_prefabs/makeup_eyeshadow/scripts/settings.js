// If the export is not a JSON string - Safari crashes applying the effect
exports = /* json */ `{
  "matte": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "matte_powder": {
    "A": 0.5,
    "C": 0.8,
    "R": 1,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "shimmer": {
    "A": 1,
    "C": 1.1,
    "R": 2,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "glitter_metallic": {
    "A": 1.3,
    "C": 1.3,
    "R": 1,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "glitter": {
    "A": 1,
    "C": 1.1,
    "R": 2,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "metallic": {
    "A": 1.3,
    "C": 1.3,
    "R": 1,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "glitter_sheer": {
    "A": 1,
    "C": 1.4,
    "R": 2,
    "P": -1,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  },
  "cream": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.25,
    "Q": 0.5
  }
}`

if (typeof module !== "undefined") module.exports = exports
