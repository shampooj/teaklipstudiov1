// If the export is not a JSON string - Safari crashes applying the effect
exports = /* json */ `{
  "matte": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "matte_powder": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "shimmer": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "glitter_metallic": {
    "A": 1.3,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "glitter": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "metallic": {
    "A": 1.3,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "glitter_sheer": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  },
  "cream": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": 0,
    "K": {
      "high": 0.6,
      "mid": 0.45,
      "low": 0.3
    },
    "T": 0.7,
    "Q": 0
  }
}`

if (typeof module !== "undefined") module.exports = exports
