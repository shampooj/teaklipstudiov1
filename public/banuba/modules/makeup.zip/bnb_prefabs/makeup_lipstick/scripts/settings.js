// If the export is not a JSON string - Safari crashes applying the effect
exports = /* json */ `{
  "matte_dry": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_cream": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_powder": {
    "A": 0.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_liquid": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "cream_shine": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "glossy_cream_plumping": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "balm": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "balm_light": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "glossy_cream_shimmer": {
    "A": 1.3,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "cream_vividcolors": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_velvet": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "cream_shine_glitter": {
    "A": 1.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "shimmer": {
    "A": 1.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_velvet_sparkling": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_sheer_lightcolors": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_cream_vividcolors": {
    "A": 0.8,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "metallic_cream": {
    "A": 1.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_velvet_sparkling_lightcolors": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "matte_light": {
    "A": 0.5,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "metallic_shine": {
    "A": 1.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "metallic_dry_lightcolors": {
    "A": 1.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "satin": {
    "A": 1.2,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "shine": {
    "A": 1.3,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "cream": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "clear": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "cream_darkcolors": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "clear_shimmer": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  },
  "metallic_sheer": {
    "A": 1,
    "C": 1,
    "R": 0,
    "P": -2,
    "K": {
      "high": 0.7,
      "mid": 0.5,
      "low": 0.3
    },
    "T": 0.35,
    "Q": 0
  }
}`

if (typeof module !== "undefined") module.exports = exports
