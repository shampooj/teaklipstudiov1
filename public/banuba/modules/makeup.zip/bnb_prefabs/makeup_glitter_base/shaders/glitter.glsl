#include <bnb/glsl.frag>

const vec3 radiance_direction = vec3(0.f, 0.f, 1.f);
const float position_scale = 0.01f;
const float domain_scale = 0.7071f; // ~= sqrt(0.5)

const float layer0_shift = 20.f;
const float layer0_power_factor = 0.21f;
const float layer0_anisotropy = 0.55f;
const float layer0_max_visibility = 0.5f;

const float layer1_shift = 5.f;
const float layer1_power_factor = 0.145f;
const float layer1_anisotropy = 0.6f;
const float layer1_max_visibility = 0.4f;

float layer_power(float factor)
{
    /* depends from screen size */
    return factor * bnb_SCREEN.x + bnb_SCREEN.y;
}

vec2 noise(BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise), vec3 x)
{
    vec3 cell = floor(x);
    vec3 frac_part = fract(x);
    frac_part = frac_part * frac_part * (3.f - 2.f * frac_part);

    vec2 uv = cell.xy + vec2(37.f, 17.f) * cell.z + frac_part.xy;

    float tex_span = float(textureSize(BNB_SAMPLER_2D(tex_noise), 0).x);
    vec4 packed_result = BNB_TEXTURE_2D(BNB_SAMPLER_2D(tex_noise), (uv + 0.5f) / tex_span);

    return mix(packed_result.yw, packed_result.xz, frac_part.z);
}

vec3 glitter_domain(vec3 position)
{
    vec3 domain = position * 0.5f;
    domain.xy = domain_scale * vec2(domain.x + domain.y, domain.y - domain.x);
    domain.xz = domain_scale * vec2(domain.x + domain.z, domain.z - domain.x);
    return domain;
}

vec3 displaced_domain(vec3 domain, vec3 footprint, vec2 shift_xy, vec2 shift_xz, float shift_amount)
{
    domain.xy -= shift_xy * shift_amount * footprint.xy;
    domain.xz -= shift_xz * shift_amount * footprint.xz;
    return domain;
}

vec3 anisotropy_field(BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise), vec3 domain, float power)
{
    vec2 noise_0 = noise(BNB_PASS_SAMPLER_ARGUMENT(tex_noise), domain * power);
    vec2 noise_1 = noise(BNB_PASS_SAMPLER_ARGUMENT(tex_noise), domain.yzx * power);
    return vec3(noise_0, noise_1.x) * 2.f - 1.f;
}

vec2 glitter_layer0(
    BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise),
    vec3 domain_base,
    vec3 footprint,
    vec3 lr,
    vec3 N,
    float nl,
    vec2 glitter_params
)
{
    vec3 domain = displaced_domain(domain_base, footprint, lr.xz, lr.xy, layer0_shift);

    float power = layer_power(layer0_power_factor);
    vec3 aniso = anisotropy_field(BNB_PASS_SAMPLER_ARGUMENT(tex_noise), domain, power);

    aniso -= N * dot(aniso, N);
    aniso /= min(1.f, length(aniso));

    float n_lr = abs(dot(N, lr));
    float a_lr = abs(dot(aniso, lr));

    float q = exp2((1.1f - layer0_anisotropy) * 3.5f);

    float lobe = pow(n_lr, q * glitter_params.y);
    lobe *= pow(1.f - a_lr * layer0_anisotropy, 10.f);

    float glitter = lobe * exp2((1.2f - layer0_anisotropy) * glitter_params.x);
    glitter *= smoothstep(0.f, layer0_max_visibility, nl);

    return vec2(glitter, lobe);
}

float glitter_layer1(
    BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise),
    vec3 domain_base,
    vec3 footprint,
    vec3 lr,
    vec3 N,
    float nl,
    vec2 glitter_params,
    float n_lr
)
{
    vec3 domain = displaced_domain(domain_base, footprint, lr.xy, lr.xz, layer1_shift);

    float power = layer_power(layer1_power_factor);
    vec3 aniso = anisotropy_field(BNB_PASS_SAMPLER_ARGUMENT(tex_noise), domain, power);

    float a_lr = abs(dot(aniso, lr));
    float q = exp2((0.1f - layer1_anisotropy) * 3.5f);

    float lobe = pow(n_lr, q * glitter_params.y);
    lobe *= pow(1.f - a_lr * layer1_anisotropy, 150.f);

    float glitter = lobe * ((1.f - layer1_anisotropy) * glitter_params.x);
    glitter *= smoothstep(0.f, layer1_max_visibility, nl);

    return glitter;
}

vec3 glitter_area(
    vec3 background,
    vec3 glitter_color,
    float alpha,
    vec3 N,
    vec3 L,
    vec4 glitter_params,
    BNB_DECLARE_SAMPLER_2D_ARGUMENT(tex_noise),
    vec3 position
)
{
    vec3 glitter_position = position * position_scale;

    vec3 lr = normalize(L + radiance_direction);
    vec3 domain_base = glitter_domain(glitter_position);
    vec3 footprint = fwidth(glitter_position);
    float nl = dot(N, L);

    vec2 layer0_glitter = glitter_layer0(
        BNB_PASS_SAMPLER_ARGUMENT(tex_noise),
        domain_base,
        footprint,
        lr,
        N,
        nl,
        glitter_params.xy
    );

    float layer1_glitter = glitter_layer1(
        BNB_PASS_SAMPLER_ARGUMENT(tex_noise),
        domain_base,
        footprint,
        lr,
        N,
        nl,
        glitter_params.zw,
        layer0_glitter.y
    );

    float glitter = (layer0_glitter.x + layer1_glitter) * alpha;

    return background + glitter * glitter * glitter_color;
}
